/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

/*  Monkey HTTP Server
 *  ==================
 *  Copyright 2001-2015 Monkey Software LLC <eduardo@monkey.io>
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

#ifndef MK_CORE_INFO_H
#define MK_CORE_INFO_H

/* General flags set by CMakeLists.txt */
#ifndef MK_THREADS_POSIX
#define MK_THREADS_POSIX
#endif
#ifndef MK_HAVE_STAT_H
#define MK_HAVE_STAT_H
#endif
#ifndef MK_HAVE_SYS_UIO_H
#define MK_HAVE_SYS_UIO_H
#endif
#ifndef MK_HAVE_MEMMEM
#define MK_HAVE_MEMMEM
#endif
#ifndef MK_HAVE_UNISTD_H
#define MK_HAVE_UNISTD_H
#endif
#ifndef MK_HAVE_TIMERFD_CREATE
#define MK_HAVE_TIMERFD_CREATE
#endif
#ifndef MK_HAVE_EVENTFD
#define MK_HAVE_EVENTFD
#endif
#ifndef MK_HAVE_MEMRCHR
#define MK_HAVE_MEMRCHR
#endif


#endif
